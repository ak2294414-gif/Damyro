// ═══════════════════════════════════════════════════════════════
// NexusAI — Supabase Configuration (LIVE)
// Admin: ak2294414@gmail.com
// ═══════════════════════════════════════════════════════════════

const SUPABASE_URL     = "https://hsrpfrhzkrlugvpngjsl.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_dmuwtMmXNzFlalnJbOBftQ_7hXKHlXd";
const ADMIN_EMAIL       = "ak2294414@gmail.com";

const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// ── Shared helpers ─────────────────────────────────────────────

async function getCurrentUser() {
  const { data: { user } } = await supabaseClient.auth.getUser();
  return user;
}

async function requireAuth() {
  const user = await getCurrentUser();
  if (!user) { window.location.href = "login.html"; return null; }
  return user;
}

async function signOutAndRedirect() {
  await supabaseClient.auth.signOut();
  window.location.href = "login.html";
}

async function getMyProfile(userId) {
  const { data, error } = await supabaseClient
    .from("profiles").select("*").eq("id", userId).maybeSingle();
  if (error) { console.error("getMyProfile:", error); return null; }
  return data;
}

async function upsertMyProfile(userId, fields) {
  const { data, error } = await supabaseClient
    .from("profiles")
    .upsert({ id: userId, ...fields, updated_at: new Date().toISOString() })
    .select().maybeSingle();
  if (error) { console.error("upsertMyProfile:", error); return null; }
  return data;
}

// Returns true if the current user is the admin
async function isAdmin() {
  const user = await getCurrentUser();
  return user && user.email === ADMIN_EMAIL;
}
