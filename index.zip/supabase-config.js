// ═══════════════════════════════════════════════════════════════
// NexusAI — Supabase Configuration
// ═══════════════════════════════════════════════════════════════
// FILL THESE TWO VALUES IN FROM YOUR SUPABASE DASHBOARD:
//   Project Settings → API → Project URL         → SUPABASE_URL
//   Project Settings → API → Project API keys →
//     "anon" "public" key (NOT the service_role key, NOT your
//     database password) → SUPABASE_ANON_KEY
//
// This anon key is SAFE to put in frontend code — it is designed
// to be public. Access control is enforced server-side by Row
// Level Security (RLS) policies, set up via the SQL script in
// supabase-setup.sql. Never put your database password or the
// service_role key in any file that ships to the browser.
// ═══════════════════════════════════════════════════════════════

const SUPABASE_URL = "https://YOUR_PROJECT_REF.supabase.co";
const SUPABASE_ANON_KEY = "YOUR_ANON_PUBLIC_KEY";

// Loaded via <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
// before this file, on every page that needs it.
const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

// ── Shared helpers used across pages ──────────────────────────

/**
 * Returns the currently signed-in Supabase user, or null.
 */
async function getCurrentUser() {
  const { data: { user } } = await supabaseClient.auth.getUser();
  return user;
}

/**
 * Redirects to login.html if nobody is signed in.
 * Call this at the top of any page that requires auth.
 */
async function requireAuth() {
  const user = await getCurrentUser();
  if (!user) {
    window.location.href = "login.html";
    return null;
  }
  return user;
}

/**
 * Signs the user out and returns to the login page.
 */
async function signOutAndRedirect() {
  await supabaseClient.auth.signOut();
  window.location.href = "login.html";
}

/**
 * Fetches the caller's own profile row (or null if not created yet).
 */
async function getMyProfile(userId) {
  const { data, error } = await supabaseClient
    .from("profiles")
    .select("*")
    .eq("id", userId)
    .maybeSingle();
  if (error) { console.error("getMyProfile error:", error); return null; }
  return data;
}

/**
 * Creates or updates the caller's own profile row.
 * RLS ensures a user can only write a row where id = auth.uid().
 */
async function upsertMyProfile(userId, fields) {
  const { data, error } = await supabaseClient
    .from("profiles")
    .upsert({ id: userId, ...fields, updated_at: new Date().toISOString() })
    .select()
    .maybeSingle();
  if (error) { console.error("upsertMyProfile error:", error); return null; }
  return data;
}
