# NorthWeb Co. — Website

Multi-page static website for NorthWeb Co., built for GitHub Pages hosting.

---

## 📁 File Structure

```
northweb/
│
├── index.html              ← Main homepage
├── 404.html                ← Custom 404 page
├── sitemap.xml             ← SEO sitemap (update domain)
├── robots.txt              ← Search engine instructions
├── llms.txt                ← AI crawler description
├── README.md               ← This file
│
├── pages/
│   ├── booking.html        ← Booking / consultation form page
│   └── policies.html       ← Privacy, Terms, Refund, Cookie policies
│
├── css/
│   ├── style.css           ← Global shared styles (nav, footer, buttons)
│   ├── home.css            ← Homepage-specific styles
│   ├── booking.css         ← Booking page styles
│   └── policies.css        ← Policies page styles
│
└── js/
    ├── components.js       ← Shared nav, footer, cookie banner (injected on every page)
    ├── sheets.js           ← Google Sheets API integration (configure URL here)
    ├── home.js             ← Homepage JS (pricing tabs, FAQ accordion)
    ├── booking.js          ← Booking form logic, validation, success page
    └── policies.js         ← Policies page scroll + active link logic
```

---

## 🚀 GitHub Pages Deployment

1. Create a new GitHub repository (e.g. `northweb-site`)
2. Upload all files maintaining the folder structure above
3. Go to **Settings → Pages**
4. Source: **Deploy from a branch** → `main` → `/ (root)`
5. Your site will be live at `https://yourusername.github.io/northweb-site/`

> **Custom domain:** Add a `CNAME` file in the root with your domain (e.g. `northweb.co`), then configure DNS at your registrar.

---

## 📊 Google Sheets Integration Setup

The booking form saves entries to a Google Sheet via Google Apps Script.

### Step 1 — Create the Google Sheet

1. Open [Google Sheets](https://sheets.google.com) → New spreadsheet
2. Rename the first sheet tab to: **Bookings**
3. Add these headers in **Row 1**:

| A | B | C | D | E | F | G |
|---|---|---|---|---|---|---|
| Timestamp | Name | WhatsApp | Business | Service | Message | Status |

### Step 2 — Create the Apps Script Web App

1. In your Google Sheet: **Extensions → Apps Script**
2. Delete all existing code
3. Paste this code:

```javascript
function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName("Bookings");
  var data = e.parameter;
  sheet.appendRow([
    new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }),
    data.name     || "",
    data.phone    || "",
    data.business || "",
    data.service  || "",
    data.message  || "",
    "New"
  ]);
  return ContentService
    .createTextOutput(JSON.stringify({ result: "success" }))
    .setMimeType(ContentService.MimeType.JSON);
}

function doGet(e) {
  return ContentService
    .createTextOutput(JSON.stringify({ status: "NorthWeb Sheets API running" }))
    .setMimeType(ContentService.MimeType.JSON);
}
```

4. Click **Deploy → New deployment**
5. Type: **Web App**
6. Execute as: **Me**
7. Who has access: **Anyone**
8. Click **Deploy** → Copy the **Web App URL**

### Step 3 — Paste URL into sheets.js

Open `js/sheets.js` and replace the URL in `SHEETS_CONFIG`:

```javascript
const SHEETS_CONFIG = {
  url: 'PASTE_YOUR_WEB_APP_URL_HERE',  // ← paste here
  ...
};
```

### Step 4 — Test

Fill in the booking form on `pages/booking.html` and check your Google Sheet — a new row should appear.

---

## 🔧 Other Configuration

| File | What to update |
|------|----------------|
| `sitemap.xml` | Replace `https://northweb.co/` with your actual domain |
| `robots.txt` | Replace `https://northweb.co/` with your actual domain |
| `llms.txt` | Update domain |
| Each HTML `<link rel="canonical">` | Replace with your actual domain |
| `js/components.js` — `WA_NUMBER`, `EMAIL` | Already set to Ankur's details |

---

## 📞 Contact

**Ankur — NorthWeb Co.**
- WhatsApp: 7637 913 832
- Email: ak2294414x@gmail.com
