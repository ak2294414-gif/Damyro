// Damyro Configuration — Update GOOGLE_SHEET_SCRIPT_URL to your deployed Apps Script web app URL
window.DAMYRO_CONFIG = {
  GOOGLE_SHEET_SCRIPT_URL: "https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec",
  GOOGLE_CLIENT_ID: "YOUR_GOOGLE_CLIENT_ID.apps.googleusercontent.com",
  BRAND_NAME: "Damyro",
  TAGLINE: "Next-Gen Web Engineering & Custom Bike Storefront"
};
